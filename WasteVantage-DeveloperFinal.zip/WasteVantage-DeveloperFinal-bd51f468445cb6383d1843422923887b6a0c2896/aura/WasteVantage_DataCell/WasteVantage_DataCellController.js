({
	init : function(component, event, helper) {
		var record = component.get('v.record');
        var field = component.get('v.field');
        component.set('v.value', record[field.name]);
	},
    handleClick : function(component, event, helper) {
        	var record = component.get('v.record');
        	var assetOfAllPos= component.get('v.assetsOfAllPos');
        console.log("assetOfAllPos:"+assetOfAllPos); 
        if(assetOfAllPos){
            
             
            var navService = component.find("navService");
        	 var pageReference = {
                "type": "standard__recordPage",
                "attributes": {
                    "recordId": record.Id,
                    "actionName": "view"
                }
        	 };
        	 navService.navigate(pageReference);
            
        }else{
            var navService = component.find("navService");
        	 var pageReference = {
                "type": "standard__recordPage",
                "attributes": {
                    "recordId": record.Id,
                    "actionName": "view"
                }
        	 };
        	 navService.navigate(pageReference);
        }
        	
   }
})