({
	getInitialValues : function(component) {
		var prepData = component.get("c.prepInitialData");
        console.log('Before success '+component.get("v.recordId"));
        prepData.setParams({
            recordId : component.get("v.recordId"),
            recordTypeName : "Inventory_Transactions",
            transactionContext : "AssetDetailPage"
        });
       prepData.setCallback(this,function(response){
           var state = response.getState();
           if(state === 'SUCCESS') {
               var prepWrapper=response.getReturnValue();
               console.log("prepWrapper.assetDetails.WasteVantage_Condition__c:"+prepWrapper.assetDetails.WasteVantage_Condition__c);
              if(prepWrapper.assetDetails.WasteVantage_Condition__c =="Lost"){
                   component.set("v.ErrorMsg","Error! Asset Condition is 'Lost'");
                   var modal = component.find("quickactionModal");
                   $A.util.removeClass(modal,"toggle");
                   $A.util.addClass(modal,"pstyle");
                }else if(prepWrapper.assetDetails.WasteVantage_Status__c!="Analysis Pending" && prepWrapper.expirationDateNotProper){
                       component.set("v.ErrorMsg",'Error! Profile Approval associated to source Asset has invalid Approval Start Date or Expiration Date');
                       var modal = component.find("quickactionModal");
                       $A.util.removeClass(modal,"toggle");
                       $A.util.addClass(modal,"pstyle");
               
                }else if(!prepWrapper.assetDetails.WasteVantage_Inventory__c)
                {
					 component.set("v.ErrorMsg","Error! Asset does not have Inventory");
                     var modal = component.find("quickactionModal");
                     $A.util.removeClass(modal,"toggle");
                     $A.util.addClass(modal,"pstyle");
                }else { console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>show");
                    var toggleText = component.find("form-container");
                    $A.util.removeClass(toggleText,"toggle");
                    
                    component.set("v.conditionList",prepWrapper.listOfConditionValues);
                    component.set("v.orderTransactionObj.RecordTypeId",prepWrapper.recordTypeId);
                    component.set("v.orderTransactionObj.Asset__c",prepWrapper.assetDetails.Id);
                    component.set("v.assetVal",prepWrapper.assetDetails.Name);
                    component.set("v.orderTransactionObj.Source_Inventory__c",prepWrapper.assetDetails.WasteVantage_Inventory__c);
                    component.set("v.srcInvVal",prepWrapper.assetDetails.WasteVantage_Inventory__r.Name);
                    component.set("v.mainacc",prepWrapper.assetDetails.WasteVantage_Account__c);
                    
                }
           }else{
               var uiErrorMessage='Unknown Error';
               if(state === 'ERROR'){
                   var errorData = response.getError()[0].message;
                   var errorClass = JSON.parse(errorData);
                   uiErrorMessage=errorClass.errorMessage;
                   console.log(errorClass.errorDetails);
    		   }else if(state === "INCOMPLETE") {
                   uiErrorMessage='Error! No response from server or client is offline';             
               }
               component.set("v.ErrorMsg",uiErrorMessage);
               var modal = component.find("quickactionModal");
               $A.util.removeClass(modal,"toggle");
               $A.util.addClass(modal,"pstyle");
           } 
       });
       $A.enqueueAction(prepData);
	},
    handleSubmit : function(component){
        var orderRecord = component.get("v.orderTransactionObj");
        var selectedLookupRecObj=component.get("v.selectedLookupRec");
        console.log("selectedLookupRecObj>> "+JSON.stringify(selectedLookupRecObj));
         if(selectedLookupRecObj.Id != undefined){
          orderRecord.Destination_Asset_Position__c = selectedLookupRecObj.Id;
        } 
        
        //Status is always in 'Received' for Inventory transactions
        orderRecord.Status__c='Received';
        var insertRecordAction = component.get("c.createTransactionRecord");
        console.log("orderRecord>> "+JSON.stringify(orderRecord));
        
        //mandatory check before submitting
        if(orderRecord.Destination_Asset_Position__c){
            insertRecordAction.setParams({
                obj : orderRecord
            });
            insertRecordAction.setCallback(this,function(response){
                var state = response.getState();
                console.log("state1 "+state);
                if(state === 'SUCCESS') {
                    console.log('Successfully inserted');
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": component.get("v.recordId"),
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                }else{
                   var uiErrorMessage='Unknown Error';
                   if(state === 'ERROR'){
                       var errorData = response.getError()[0].message;
                       var errorClass = JSON.parse(errorData);
                       uiErrorMessage=errorClass.errorMessage;
                       console.log(errorClass.errorDetails);
                   }else if(state === "INCOMPLETE") {
                       uiErrorMessage='Error! No response from server or client is offline';             
                   }
                   component.set("v.ErrorMsg",uiErrorMessage);
                   var modal = component.find("quickactionModal");
                   $A.util.removeClass(modal,"toggle");
                   $A.util.addClass(modal,"pstyle");
               } 
            });
            $A.enqueueAction(insertRecordAction);
        }else{
            var uiErrorMessage="Error! 'Destination Container/Asset Location' is mandatory to create this Transaction";
            component.set("v.ErrorMsg",uiErrorMessage);
            var modal = component.find("quickactionModal");
            $A.util.removeClass(modal,"toggle");
            $A.util.addClass(modal,"pstyle");
        }
        
    }
})