/* helper.js */
({
    // Component Initialization
    doInit : function(component, event) {
        var showModal = component.get("v.showModal");
        component.set("v.showSpinner",true);
        var soId = component.get("v.recordId");
        if(!$A.util.isUndefinedOrNull(soId)){            
            var action = component.get("c.fetchSOInformations");
            action.setParams({ soId : soId});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var soDetails = response.getReturnValue();     
                    //console.log('soDetails '+JSON.stringify(soDetails));
                    if(!$A.util.isUndefinedOrNull(soDetails)){ 
                        if(!$A.util.isUndefinedOrNull(soDetails.assetItems)){
                            var assets = soDetails.assetItems;
                            if(assets.length > 0){
                                component.set("v.maxPage_Asset", Math.floor((assets.length + 9) / 10));
                                if(!$A.util.isUndefinedOrNull(soDetails.selectedAssetInfoMap)){
                                    var assetMap = soDetails.selectedAssetInfoMap;
                                    var assetIds = [];
                                    for(var assetKey in assetMap ){
                                        assetIds.push(assetKey);    
                                    }
                                    component.set("v.selectedAssets",assetIds);    
                                }
                                this.initializeAssetTable(component, event, assets);
                            }
                            else{
                                if(soDetails.soStatus === $A.get("$Label.c.WM_SOStatus_Completed")){
                                    component.set("v.maxPage_Asset",1);
                                    component.set("v.pageNumber_Asset",1);
                                }
                                else{
                                    var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        "title": "Error !",
                                        "type": "error",
                                        "message": $A.get("$Label.c.WM_NoAssetsFound")
                                    });
                                    $A.get("e.force:closeQuickAction").fire();   
                                    toastEvent.fire();
                                }
                            }
                        }
                        if(!$A.util.isUndefinedOrNull(soDetails.soStatus)){
                            component.set("v.soStatus",soDetails.soStatus);
                        }
                        if(!$A.util.isUndefinedOrNull(soDetails.pdTypeMap)){
                            component.set("v.pdTypeMap",soDetails.pdTypeMap);  
                            this.setPDFilters(component, event, soDetails.pdTypeMap);
                        }
                        if(!$A.util.isUndefinedOrNull(soDetails.soliItems)){
                            var soliList = soDetails.soliItems;
                            component.set("v.soliWrapper",soliList);
                            component.set("v.maxPage_SOLI", Math.floor((soliList.length + 9) / 10));
                            this.setSOLITable(component, event, soliList);
                        }
                    }
                    else{
                        $A.get("e.force:closeQuickAction").fire(); 
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "type": "error",
                            "message": $A.get("$Label.c.WM_NoAssetsFound") 
                        });
                        toastEvent.fire();
                        $A.get("e.force:closeQuickAction").fire();
                    }
                    component.set("v.showSpinner",false);
                    if(!showModal){
                        $A.get('e.force:refreshView').fire();
                        $A.get("e.force:closeQuickAction").fire();
                    }
                    component.set("v.showModal",false);                   
                }
                else if (state === "INCOMPLETE") {
                    component.set("v.showSpinner",false);
                }
                    else if (state === "ERROR") {
                        var errors = response.getError();
                        if (errors) {
                            if (errors[0] && errors[0].message) {
                                console.log("Error message: " + errors[0].message);
                                $A.get("e.force:closeQuickAction").fire(); 
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    "title": "Error!",
                                    "type": "error",
                                    "message": errors[0].message
                                });
                                toastEvent.fire();
                            }
                        } else {
                            console.log("Unknown error");
                        }
                        component.set("v.showSpinner",false);
                        
                    }
            });
            $A.enqueueAction(action);
        }  
    },
    
    // Initialize Data Table
    initializeAssetTable : function(component, event, assets) {
        var assetMap = component.get("v.assetMap");
        var headerActions = [
            {
                label: 'Filter',
                name:'filter'
            }
        ];
        component.set('v.assetColumns', [
            {label: 'Asset Physical Id', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'assetName_Text' }, target: '_blank'}},
            {label: 'Profile Detail Name', fieldName: 'profileDetailName', type: 'text', actions: headerActions} ,           
            {label: 'Status', fieldName: 'assetStatus', type: 'text'},
            {label: 'Waste Stream Name', fieldName: 'wasteStreamName', type: 'text'},
            /*{label: 'Disposal Weight', fieldName: 'disposalWeight', type: 'text'},
            {label: 'Disposal UOM', fieldName: 'disposalUOM', type: 'text'},*/
        ]);  
            assets.forEach(function(record){
            if(!$A.util.isUndefinedOrNull(record.assetName_Text)){ 
            if(record.assetName_Text !== ''){
            record.linkName = '/'+record.assetID;
            }
            }
            });
        component.set("v.assetItems", assets);
        component.set("v.assetItemsTrue", assets);        
        for(var key in assets){
            var asset = assets[key];
            assetMap[asset.assetID] = 'false';
        }
        component.set("v.assetMap",assetMap);
        this.performAssetPagination(component, event);
        //console.log('initializeAssetTable  assetMap '+JSON.stringify(component.get("v.assetMap")));        
    },
    
    // Set PD Types
    setPDFilters : function(component, event, pdTypes) {
        component.set("v.pdOptions",[]);
        var options = component.get("v.pdOptions");
        options.push({label:'All',value:'All'});
        //console.log("pdTypes "+JSON.stringify(pdTypes));
        for(var pdtype in pdTypes){
            if(!$A.util.isUndefinedOrNull(pdTypes[pdtype])){
                options.push({
                    label:pdTypes[pdtype],
                    value:pdTypes[pdtype]});
            }
        }
        component.set("v.pdOptions",options);
    },
    
    // Initialize Data Table
    setSOLITable : function(component, event, soliList){  
        var tempAssetMap = component.get("v.assetMap");
        var assetIds = [];
        component.set('v.soliColumns', [
            {label: 'Container Type', fieldName: 'containerType', type: 'text'},
            {label: 'Profile Detail Name', fieldName: 'approvalName', type: 'text'},            
            {label: 'Estimated Volume', fieldName: 'quantity', type: 'number',typeAttributes: { minimumFractionDigits : '2' }},
            {label: 'Dispatched UOM', fieldName: 'uom', type: 'text'},
            {label: 'Total Quantity', fieldName: 'noofAssets', type: 'number'},
            {label: 'Waste Stream Name', fieldName: 'wasteStreamName', type: 'text'}          
        ]);
        component.set("v.soliItems",soliList);
        var selAssets = component.get("v.selectedAssets");
        if(!$A.util.isUndefinedOrNull(selAssets)){
            for(var key in selAssets){
                var assetId = selAssets[key];
                if(!$A.util.isUndefinedOrNull(tempAssetMap[assetId])){
                    tempAssetMap[assetId] = 'true';   
                    assetIds.push(assetId);
                }
            }   
        }
        
        component.set("v.assetMap",tempAssetMap);
        component.set("v.selectedAssetsTemp",assetIds);
        this.performSOLIPagination(component, event);        
    },
    
    addSOLI : function(component, event){
        var saveStatus = component.get("v.saveActionInitiated"); 
        if(!saveStatus){
            component.set("v.saveActionInitiated",true);
            var soId = component.get("v.recordId");
            var assetMap = component.get("v.assetMap");
            if(!$A.util.isUndefinedOrNull(soId)){
                var action = component.get("c.createSOLineItems");
                action.setParams({soId : soId, assetIdMap : assetMap});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        this.doInit(component,event);    
                    }
                    else if (state === "INCOMPLETE") {
                    }
                        else if (state === "ERROR") {
                            var errors = response.getError();
                            if (errors) {
                                if (errors[0] && errors[0].message) {
                                    $A.get("e.force:closeQuickAction").fire(); 
                                    console.log("Error message: " + errors[0].message);
                                    var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        "title": "Error!",
                                        "type": "error",
                                        "message": errors[0].message
                                    });
                                    toastEvent.fire();
                                }
                            } else {
                                console.log("Unknown error");
                            }
                        }
                    component.set("v.saveActionInitiated",false);                    
                });
                $A.enqueueAction(action);
                
            }    
        }
    },
    updateSOLI : function(component, event){
        var soId = component.get("v.recordId");
        var assetMap = component.get("v.assetMap");
        if(!$A.util.isUndefinedOrNull(soId)){
            var action = component.get("c.updateSOLineItems");
            action.setParams({soId : soId, assetIdMap : assetMap});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    this.doInit(component,event);   
                }
                else if (state === "INCOMPLETE") {
                }
                    else if (state === "ERROR") {
                        var errors = response.getError();
                        if (errors) {
                            if (errors[0] && errors[0].message) {
                                $A.get("e.force:closeQuickAction").fire(); 
                                console.log("Error message: " + errors[0].message);
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    "title": "Error!",
                                    "type": "error",
                                    "message": errors[0].message
                                });
                                toastEvent.fire();
                            }
                        } else {
                            console.log("Unknown error");
                        }
                    }
                component.set("v.updateActionIntiated",false);
            });
            $A.enqueueAction(action);
            
        } 
    },
    performAssetPagination : function(component, event, helper) {
        var pageNumber = component.get("v.pageNumber_Asset");
        var assetItems = component.get("v.assetItems");
        var selAssets = component.get("v.selectedAssets");
        var assetItemsToShow = component.get("v.assetItemsToShow");
        var tempAssetIds = [];
        var currentPageRecords = assetItems.slice((pageNumber - 1) * 10, pageNumber * 10);
        var tempAssetMap = component.get("v.assetMap");
        component.set("v.assetItemsToShow", currentPageRecords);        
        for(var assetKey in currentPageRecords){
            var assetId = currentPageRecords[assetKey].assetID;
            if(tempAssetMap[assetId] == 'true'){
                tempAssetIds.push(assetId)   ;
            }            
        }
        component.set("v.selectedAssetsTemp",tempAssetIds);
    },
    
    performSOLIPagination : function(component, event, helper) {
        var pageNumber = component.get("v.pageNumber_SOLI");
        var soliItems = component.get("v.soliItems");
        var tempAssetMap = component.get("v.assetMap");
        var currentPageRecords = soliItems.slice((pageNumber - 1) * 10, pageNumber * 10);   
        var tempAssetIds = [];
        component.set("v.soliItemsToShow", currentPageRecords);
        /*for(var assetKey in currentPageRecords){
            var assetId = currentPageRecords[assetKey].assetID;
            if(tempAssetMap[assetId] == 'true'){
                tempAssetIds.push(assetId)   ;
            }
        }
        component.set("v.selectedAssetsTemp",tempAssetIds);*/
    },    
})