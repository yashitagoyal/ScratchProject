/* controller.js */
({
    // Component Initialization
    onInit : function(component, event, helper) {
        helper.doInit(component,event);
    },
    
    // Close Quick Action Modal
    handleModalClose : function(component, event, helper) {
        $A.get('e.force:refreshView').fire();
        $A.get("e.force:closeQuickAction").fire();   
    },
    
    // Store assets on selection
    handleRowAction : function(component, event, helper) {
        var pdStatus = component.get("v.checkPDChange");
        if(!pdStatus){
            var selectedRows = event.getParam('selectedRows');
            var assetItemsToShow = component.get("v.assetItemsToShow");
            var tempAssetMap = component.get("v.assetMap");
            if(!$A.util.isUndefinedOrNull(selectedRows)){
                if(selectedRows.length > 0){
                    var assetIdList = [];
                    for(var key in selectedRows){
                        var assetId = selectedRows[key].assetID;
                        assetIdList.push(assetId);     
                    } 
                    for(var assetKey in assetItemsToShow){
                        var assetId = assetItemsToShow[assetKey].assetID;
                        if(assetIdList.includes(assetId)){
                            tempAssetMap[assetId] = 'true';
                        }
                        else{                    
                            tempAssetMap[assetId] = 'false';
                        }          
                    }
                    //component.set("v.assetMap",tempAssetMap);
                }
                else{
                    for(var assetKey in assetItemsToShow){
                        var assetId = assetItemsToShow[assetKey].assetID;
                        tempAssetMap[assetId] = 'false';
                    }
                }
            }
        }
    },
    
    // Open PDTypes Section
    handleHeaderAction : function(component, event, helper) {
        component.set("v.showPDFilters",true);
    },
    
    // Filter asset list on PD Type selection
    handlePDFilterChange : function(component, event, helper) {
        component.set("v.checkPDChange",true);
        var selectedPDName = component.get("v.pdValue");
        var assetListTrue = component.get("v.assetItemsTrue");
        var newAssetList = [];
        var assetIds = [];
        if(selectedPDName === 'All'){
            component.set("v.maxPage_Asset", Math.floor((assetListTrue.length + 9) / 10));
            component.set("v.assetItems",assetListTrue);
            component.set("v.pageNumber_Asset",1);
        }
        else{
            for(var key in assetListTrue){
                if(!$A.util.isUndefinedOrNull(assetListTrue[key].profileDetailName)){
                    var asset = assetListTrue[key];
                    if(asset.profileDetailName == selectedPDName){
                        newAssetList.push(asset);
                    }
                }            
            }
            component.set("v.pageNumber_Asset",1);
            component.set("v.maxPage_Asset", Math.floor((newAssetList.length + 9) / 10));
            component.set("v.assetItems",newAssetList);
        }
        helper.performAssetPagination(component, event);  
        /*component.set("v.checkPDChange",false);
        if(!$A.util.isUndefinedOrNull(assetIds)){
            	component.set("v.selectedAssets",assetIds);    
        }*/
        component.set("v.checkPDChange",false);
    },
    
    // Hide PDTypes Section
    handleHidePDFilters : function(component, event, helper) {
        component.set("v.showPDFilters",false);
    },
    
    // Select asset records based upon filter selection
    handleAssetSelection : function(component, event, helper) {
        var assetIdMap = component.get("v.assetMap");
        var assetIds = [];
        for(var key in assetIdMap){
            if(assetIdMap[key] == 'true'){
                assetIds.push(key);    
            }    
        }
        //component.set('v.selectedAssetsTemp', assetIds);
    },
	
    // Add or Create SOLI
    handleaddSOLI : function(component, event, helper) {
    	helper.addSOLI(component, event);    
    },
    
    // Update SOLI Tree
    handleUpdateSOLI : function(component, event, helper) {
        component.set("v.updateActionIntiated",true);
        helper.updateSOLI(component, event);
    },
    
    doAssetPagination : function(component, event, helper) {
        component.set("v.checkPDChange",true);
        helper.performAssetPagination(component, event);  
        component.set("v.checkPDChange",false);
        
    },
    doSOLIPagination : function(component, event, helper) {
        component.set("v.checkPDChange",true);
        helper.performSOLIPagination(component, event);  
        component.set("v.checkPDChange",false);
    }    
})