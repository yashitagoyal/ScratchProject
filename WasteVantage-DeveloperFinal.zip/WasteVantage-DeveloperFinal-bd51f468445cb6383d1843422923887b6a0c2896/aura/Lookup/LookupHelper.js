/*helper.js*/
({
    //Handle server side action to fetch record Info
    fetchRecordDetails : function(component,event,getInputkeyWord) {
        var objName = component.get("v.objectAPIName");
        var recId = component.get("v.recId");
        var action = component.get("c.fetchLookUpValuesById");
        action.setParams({
            'ObjectName' : objName,
            'recId' : recId
        });
        // set a callBack    
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                if(!$A.util.isUndefinedOrNull(storeResponse)){                   
                    //console.log('response 2'+storeResponse);
                    // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                    if(storeResponse.length > 0){
                        component.set("v.selectedRecord" , storeResponse[0]);                   
                        var forclose = component.find("lookup-pill");
                        $A.util.addClass(forclose, 'slds-show');
                        $A.util.removeClass(forclose, 'slds-hide');
                        
                        var forclose = component.find("searchRes");
                        $A.util.addClass(forclose, 'slds-is-close');
                        $A.util.removeClass(forclose, 'slds-is-open');
                        
                        var lookUpTarget = component.find("lookupField");
                        $A.util.addClass(lookUpTarget, 'slds-hide');
                        $A.util.removeClass(lookUpTarget, 'slds-show');  
                    }
                    
                    if (storeResponse.length == 0) {
                        component.set("v.Message", 'No Result Found...');
                    } else {
                        component.set("v.Message", '');
                    }
                    // set searchResult list with return value from server.
                    component.set("v.listOfSearchRecords", storeResponse);
                }
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        
        
    },
    
    //Handle server side action to fetch record Info
    searchHelper : function(component,event,getInputkeyWord) {
        var objName = component.get("v.objectAPIName");
        var accId = component.get("v.accountId");
        var dependent = component.get("v.dependent");
        var excludeRecord = component.get("v.excludeRecId");
        var trxnType = component.get("v.transactionType");
        console.log('excludeRecord:'+excludeRecord);
        var action = component.get("c.fetchLookUpValues");
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : objName,
            'accId' : accId,
            'dependent' : dependent,
            'excludeRecId' : excludeRecord,
            'transactionType' : trxnType
        });
        // set a callBack    
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                //console.log('response '+storeResponse);
                // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Results Found...');
                } else {
                    component.set("v.Message", '');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        
    },
})