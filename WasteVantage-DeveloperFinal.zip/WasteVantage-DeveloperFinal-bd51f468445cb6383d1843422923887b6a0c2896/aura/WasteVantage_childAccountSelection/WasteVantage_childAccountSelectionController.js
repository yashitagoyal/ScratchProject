({
    doInit : function(component, event, helper) {
        helper.doInit(component,event);
    },
    
    handleRadioGroupChange : function(component,event,helper){
        var changeValue = event.getParam("value");
        component.set("v.radioGrpValue",changeValue);
    },
    
    saveRecord : function(component,event,helper){
        helper.saveProfileRecord(component,event);
    }
})