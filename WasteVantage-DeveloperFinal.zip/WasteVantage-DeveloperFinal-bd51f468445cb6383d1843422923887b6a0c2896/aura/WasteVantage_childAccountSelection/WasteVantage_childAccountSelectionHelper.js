({
    doInit : function(component, event, helper) {
        var action = component.get("c.getChildAccounts");
        var recId = component.get("v.recordId");
        var parentAccountName = component.get("v.ProfileApprovalRecord.Waste_Stream__r.Account_Name__c");
        action.setParams({
            'profileApprovalRecordId' : recId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var returnVal = response.getReturnValue();
                if(returnVal === undefined || returnVal === null){
                    console.log('Account is null');
                    component.set("v.noParentAccount",true);
                }
                else
                {   
                var finalList = [];
                for(var i=0; i<returnVal.length; i++)
                {
                    var childAcc = returnVal[i].WasteVantage_ChildAccounts__r;
                    if(childAcc === undefined){
                        component.set("v.isParentAccount",true);
                    }
                    else{
                        for(var j=0; j<childAcc.length; j++){
                            console.log('name is '+childAcc[j].Name);
                            childAcc[j].label = childAcc[j].Name;
                            childAcc[j].value = childAcc[j].Id;
                        }
                    }
                    finalList.push(returnVal[i]); 
                }
                component.set("v.options",finalList);
            }
            }
            else{
                console.log('Problem getting account, response state: ' + state);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    saveProfileRecord : function(component,event) {
        var radioGrpValue = component.get("v.radioGrpValue");
        var saveAction = component.get("c.saveProfileAppRecord");
        var recId = component.get("v.recordId");
        if(radioGrpValue == 'Default'){
            radioGrpValue = component.get("v.ProfileApprovalRecord.Waste_Stream__r.Account_Name__c");
        }
        saveAction.setParams({
            "recordId" : component.get("v.recordId"),
            "accountId" : radioGrpValue
        });
        saveAction.setCallback(this,function(response){
            var state = response.getState();
            var recId = component.get("v.recordId");
            if(state === "SUCCESS"){
                window.location.reload();
            }
            else{
                console.log('There was an error');
                component.set("v.invalidParentAccount",true);
            }
        });
        $A.enqueueAction(saveAction); 
    }
})