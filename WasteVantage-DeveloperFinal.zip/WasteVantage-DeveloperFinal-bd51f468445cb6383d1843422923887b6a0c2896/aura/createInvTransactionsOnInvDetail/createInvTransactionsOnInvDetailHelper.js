({
	getInitialValues : function(component) {
		var prepData = component.get("c.prepInitialData");
        console.log('Before success '+component.get("v.recordId"));
        prepData.setParams({
            recordId : component.get("v.recordId"),
            recordTypeName : "Inventory_Transactions",
            transactionContext : "InventoryDetailPage"
        });
       prepData.setCallback(this,function(response){
           var state = response.getState();
           if(state === 'SUCCESS') {
               var prepWrapper=response.getReturnValue();
               
               var toggleText = component.find("form-container");
               $A.util.removeClass(toggleText,"toggle");
               
               component.set("v.conditionList",prepWrapper.listOfConditionValues);
               component.set("v.orderTransactionObj.RecordTypeId",prepWrapper.recordTypeId);
               component.set("v.orderTransactionObj.Source_Inventory__c",prepWrapper.inventoryDetails.Id);
               component.set("v.srcInvVal",prepWrapper.inventoryDetails.Name);
               component.set("v.mainacc",prepWrapper.inventoryDetails.Account__c);
                    
                
           }else{
               var uiErrorMessage='Unknown Error';
               if(state === 'ERROR'){
                   var errorData = response.getError()[0].message;
                   var errorClass = JSON.parse(errorData);
                   uiErrorMessage=errorClass.errorMessage;
                   console.log(errorClass.errorDetails);
    		   }else if(state === "INCOMPLETE") {
                   uiErrorMessage='Error! No response from server or client is offline';             
               }
               component.set("v.ErrorMsg",uiErrorMessage);
               var modal = component.find("quickactionModal");
               $A.util.removeClass(modal,"toggle");
               $A.util.addClass(modal,"pstyle");
           } 
       });
       $A.enqueueAction(prepData);
	},
    handleSubmit : function(component){
        var orderRecord = component.get("v.orderTransactionObj");
        var selectedLookupRecObjAsset=component.get("v.selectedLookupRecAsset");
        var selectedLookupRecObjInv=component.get("v.selectedLookupRecInv");
        
        if(selectedLookupRecObjAsset.Id != undefined){
          orderRecord.Asset__c = selectedLookupRecObjAsset.Id;
        } 
        if(selectedLookupRecObjInv.Id != undefined){
          orderRecord.Destination_Asset_Position__c = selectedLookupRecObjInv.Id;
        } 
        //Status is always in 'Received' for Inventory transactions
        orderRecord.Status__c='Received';
        var insertRecordAction = component.get("c.createTransactionRecord");
        console.log("orderRecord>> "+JSON.stringify(orderRecord));
        
        //mandatory check before submitting
        if(orderRecord.Destination_Asset_Position__c && orderRecord.Asset__c){
            insertRecordAction.setParams({
                obj : orderRecord
            });
            insertRecordAction.setCallback(this,function(response){
                var state = response.getState();
                console.log("stateOfinsertRecordAction "+state);
                if(state === 'SUCCESS') {
                    console.log('Successfully inserted');
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": component.get("v.recordId"),
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                }else{
                   var uiErrorMessage='Unknown Error';
                   if(state === 'ERROR'){
                       var errorData = response.getError()[0].message;
                       var errorClass = JSON.parse(errorData);
                       uiErrorMessage=errorClass.errorMessage;
                       console.log(errorClass.errorDetails);
                   }else if(state === "INCOMPLETE") {
                       uiErrorMessage='Error! No response from server or client is offline';             
                   }
                   component.set("v.ErrorMsg",uiErrorMessage);
                   var modal = component.find("quickactionModal");
                   $A.util.removeClass(modal,"toggle");
                   $A.util.addClass(modal,"pstyle");
               } 
            });
            $A.enqueueAction(insertRecordAction);
        }else{
            var uiErrorMessage="Error! 'Asset' or 'Destination Container/Asset Location' are missing";
            component.set("v.ErrorMsg",uiErrorMessage);
            var modal = component.find("quickactionModal");
            $A.util.removeClass(modal,"toggle");
            $A.util.addClass(modal,"pstyle");
        }
        
    }
})