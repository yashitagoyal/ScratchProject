({
    doInit: function(component,event,helper){
       helper.getInitialValues(component);
   },
    handleClick : function(component,event,helper){
       helper.handleSubmit(component);
   }
})