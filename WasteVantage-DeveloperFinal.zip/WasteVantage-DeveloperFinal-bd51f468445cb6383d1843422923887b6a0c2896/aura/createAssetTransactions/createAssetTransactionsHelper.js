({
	getInitialValues : function(component) {
		var prepData = component.get("c.prepInitialData");
        console.log('Before success '+component.get("v.recordId"));
        prepData.setParams({
            recordId : component.get("v.recordId"),
            recordTypeName : "Asset_Transactions",
            transactionContext : "AssetDetailPage"
        });
       prepData.setCallback(this,function(response){
           var state = response.getState();
           if(state === 'SUCCESS') {
               var prepWrapper=response.getReturnValue();
               console.log("prepWrapper.assetDetails.WasteVantage_Condition__c:"+prepWrapper.assetDetails.WasteVantage_Condition__c);
               console.log("prepWrapper.expirationDateNotProper:"+prepWrapper.expirationDateNotProper);
               
               if(prepWrapper.assetDetails.WasteVantage_Condition__c =="Lost"){
                   component.set("v.ErrorMsg","Error! Asset Condition is 'Lost'");
                   var modal = component.find("quickactionModal");
                   $A.util.removeClass(modal,"toggle");
                   $A.util.addClass(modal,"pstyle");
               }else if( prepWrapper.assetDetails.WasteVantage_Status__c!="Analysis Pending" && !prepWrapper.assetDetails.WasteVantage_Profile_Details_ID__c){
                       component.set("v.ErrorMsg",'Error! Profile Approval not associated to source Asset');
                       var modal = component.find("quickactionModal");
                       $A.util.removeClass(modal,"toggle");
                       $A.util.addClass(modal,"pstyle");
               
               }else if(prepWrapper.assetDetails.WasteVantage_Status__c!="Analysis Pending" && prepWrapper.expirationDateNotProper){
                       component.set("v.ErrorMsg",'Error! Profile Approval associated to source Asset has invalid Approval Start Date or Expiration Date');
                       var modal = component.find("quickactionModal");
                       $A.util.removeClass(modal,"toggle");
                       $A.util.addClass(modal,"pstyle");
               }
               else
                {
                    var toggleText = component.find("form-container");
                    $A.util.removeClass(toggleText,"toggle");
                    component.set("v.statusList",prepWrapper.listOfStatusValues);
                    
                    component.set("v.orderTransactionObj.RecordTypeId",prepWrapper.recordTypeId);
                    component.set("v.orderTransactionObj.Asset_From__c",prepWrapper.assetDetails.Id);
                    component.set("v.assetVal",prepWrapper.assetDetails.Name);
                    component.set("v.mainacc",prepWrapper.assetDetails.WasteVantage_Account__c);
                    
                }
           }else{
               var uiErrorMessage='Unknown Error';
               if(state === 'ERROR'){
                   var errorData = response.getError()[0].message;
                   var errorClass = JSON.parse(errorData);
                   uiErrorMessage=errorClass.errorMessage;
                   console.log(errorClass.errorDetails);
    		   }else if(state === "INCOMPLETE") {
                   uiErrorMessage='Error! No response from server or you are offline';             
               }
               component.set("v.ErrorMsg",uiErrorMessage);
               var modal = component.find("quickactionModal");
               $A.util.removeClass(modal,"toggle");
               $A.util.addClass(modal,"pstyle");
           } 
       });
       $A.enqueueAction(prepData);
	},
    handleSubmit : function(component){
        var orderRecord = component.get("v.orderTransactionObj");
        var selectedLookupRecObj=component.get("v.selectedLookupRec");
        console.log("selectedLookupRecObj>> "+JSON.stringify(selectedLookupRecObj));
         if(selectedLookupRecObj.Id != undefined){
          orderRecord.Asset_To__c = selectedLookupRecObj.Id;
        } 
        
        var insertRecordAction = component.get("c.createTransactionRecord");
        console.log("orderRecord>> "+JSON.stringify(orderRecord));
        
        //mandatory check before submitting
        if(orderRecord.Asset_To__c){
            insertRecordAction.setParams({
                obj : orderRecord
            });
            insertRecordAction.setCallback(this,function(response){
                var state = response.getState();
                console.log("state1 "+state);
                if(state === 'SUCCESS') {
                    console.log('Successfully inserted');
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": component.get("v.recordId"),
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                }else{
                   var uiErrorMessage='Unknown Error';
                   if(state === 'ERROR'){
                       var errorData = response.getError()[0].message;
                       var errorClass = JSON.parse(errorData);
                       uiErrorMessage=errorClass.errorMessage;
                       console.log(errorClass.errorDetails);
                   }else if(state === "INCOMPLETE") {
                       uiErrorMessage='Error! No response from server or you are offline';             
                   }
                   component.set("v.ErrorMsg",uiErrorMessage);
                   var modal = component.find("quickactionModal");
                   $A.util.removeClass(modal,"toggle");
                   $A.util.addClass(modal,"pstyle");
               } 
            });
            $A.enqueueAction(insertRecordAction);
        }else{
            var uiErrorMessage="Error! 'Asset To' is mandatory to create this Transaction";
            component.set("v.ErrorMsg",uiErrorMessage);
            var modal = component.find("quickactionModal");
            $A.util.removeClass(modal,"toggle");
            $A.util.addClass(modal,"pstyle");
        }
        
    }
})