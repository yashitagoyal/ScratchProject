({
    doInit : function(component, event, helper) 
    {
        var sectionAction= component.get("c.getSections");
        var recordId = component.get("v.recordId");
        sectionAction.setParams({
            invHdrId: recordId
        });
        sectionAction.setCallback(this,function(response)
                                  {
                                      var state= response.getState();
                                      if(state == 'SUCCESS')
                                      {
                                          var sectionList = response.getReturnValue();
                                          component.set("v.sectionList",sectionList);
                                      }
                                  });
        $A.enqueueAction(sectionAction);
        
        var testAction= component.get("c.getTest");
        var recordId = component.get("v.recordId");
        testAction.setParams({
            invHdrId: recordId
        });
        testAction.setCallback(this,function(response)
                               {
                                   var state= response.getState();
                                   if(state == 'SUCCESS')
                                   {
                                       var testList = response.getReturnValue();
                                       console.log('sectionList '+testList[0].isc.Name);
                                       component.set("v.testList",testList);
                                   }
                               });
        $A.enqueueAction(testAction);
    },
    handleSave : function(component,event,helper){
        var upsertAction = component.get("c.saveRecord");
        var testList = component.get("v.testList");
        var recordId = component.get("v.recordId");
        var lstIst = [];
        testList.forEach(myFunction);
        function myFunction(value, index, array) {
            value.lstist.forEach(myFunction2);
        }
        function myFunction2(value,index,array){
            lstIst.push(value);
        }
        component.set("v.instructionTestList",lstIst);
        upsertAction.setParams({
            testList : lstIst,
            invHdrId : recordId
        });
        upsertAction.setCallback(this,function(response)
                                 {
                                     var state= response.getState();
                                     if(state == 'SUCCESS')
                                     {
                                         var navService = component.find("navService");
                                         var pageReference = {
                                             "type": "standard__recordPage",
                                             "attributes": {
                                                 "recordId": recordId,
                                                 "actionName": "view"
                                             }
                                         };
                                         navService.navigate(pageReference);
                                     }
                                 });
        $A.enqueueAction(upsertAction);
    }
})