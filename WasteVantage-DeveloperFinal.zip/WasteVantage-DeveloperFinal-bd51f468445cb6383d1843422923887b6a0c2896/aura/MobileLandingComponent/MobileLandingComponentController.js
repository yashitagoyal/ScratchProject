({
    scanQRCode : function(component, event, helper) {
        var vfurl='/apex/QRScanPage';
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url":vfurl
        });
        urlEvent.fire();
        
    },
    createShippingOrder : function(component, event, helper) {
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({"entityApiName": "Shipping_Order__c"});
        createRecordEvent.fire();        
    },
    newInspChk : function(component, event, helper){
        var createRecordEvent = $A.get("e.force:createRecord");
    createRecordEvent.setParams({
        "entityApiName": "Instruction_Test_Header__c"
    });
    createRecordEvent.fire();
    },
    createTask : function(component,event,helper){
        var createTaskRec = $A.get("e.force:createRecord");
        createTaskRec.setParams(
            {"entityApiName": "Task"}
        );
        createTaskRec.fire();
    }
})